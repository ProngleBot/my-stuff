import gspread,pprint
from oauth2client.service_account import ServiceAccountCredentials

#important stuff
scope = ['https://spreadsheets.google.com/feeds', 'https://www.googleapis.com/auth/drive']
creds = ServiceAccountCredentials.from_json_keyfile_name('client_secret.json',scope)
client = gspread.authorize(creds)
sheet = client.open('Art Contest').sheet1
pp = pprint
#formatted thingies
class Format:
    underline = '\033[4m'
    enderline = '\033[0m'
    bold = '\033[1m'
    unbold = '\033[0;0m'
def listsub():
    submitters = sheet.get_all_records()
    pp.pprint(submitters)
def submit():
    row=[]
    name = input('Enter Name:')
    cid  = input('Enter Contestant ID:')
    sub  = input('Paste Submission(note:dont ctrl+v):') 
    row.append(name)
    row.append(cid)
    row.append(sub)
    sheet.insert_row(row,2)
    cont = input('do you wish to add another submission?[y/n]').lower()
    if cont == 'y':
        print('alright')
        submit()
    elif cont == 'n':
        contmenu = input('alright do you wish to go back to menu?[y/n]')
        if contmenu == 'y':
            print('oki')
            menu()
        else:
            print('Qutting NASU Now!')

def menu():
    #drivers
    print('                          ' + Format.underline+'NASU\n' +Format.enderline + Format.underline + '\nTop class menu' + Format.enderline) 
    print("\nTo make a submission type:'Sub'\n\nTo see a list of submissions type'List Sub'\n\nIf you want to know more about NASU type 'about',\n\nTo exit the program type 'exit'")
    print('=======================================================================')
    response = input('Enter your request here:').lower()
    if response == 'sub':
        submit()
        cont = input('Do you wish to add another submission?[y/n]').lower()
        if cont =='y':
            print('New Submission')
            submit()
        elif cont =='n':
            print('alright')
            menu()
        cont      
    elif response =='list sub':
        listsub()
        question = input('Do you wish to go back to the menu?[y/n]').lower()
        if question == 'y':
            print('Alright!')
            menu()
        elif question == 'n':
            print('okay bye :)')
    elif response == 'about':
        print('\nNASU(Nightjar Art Submission Uploader) is a python script that uploads and updates a spreadsheet document.')
        __ = input('Do you want to go back to the menu?[y/n]')
        if __ == 'y':
            print('okay')
            menu()
        elif __ == 'n':
            x = input('uhm.. what do you wanna do then quit?[y/n]').lower()
            if x == 'y':
                print('okay bye ily')
            elif x == 'n':
                print('... i dont know what you want to do with me now maybe its just better to quit this awkward uhhhh bye.')
    elif response =='exit':
        print('bai ily')
menu()