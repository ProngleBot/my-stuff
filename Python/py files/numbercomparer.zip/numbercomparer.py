import sys
x = input("Enter First Number:") 
y = input ("Enter Second Number:")

if x.isdigit() & y.isdigit() == True:
    if x == y:
        print("\nThese numbers are equal :)\n",x, "was first number", y, "was second number.") 
    if x < y:
        print("\nSecond number is Bigger than First Number :).\n",x, "was first number", y, "and was second number.")
    if x > y:
        print("\nFirst number is Bigger than Second Number :).\n",x, "was first number", y, "and was second number.") 

if x.isdigit() == False:
    print("\nError at First Number.\n Please check if you have typed a number.")

if y.isdigit() == False:
    print("\nError at Second Number.\n Please check if you have typed a number.")